class Recipe < ActiveRecord::Base
  belongs_to :category
end
