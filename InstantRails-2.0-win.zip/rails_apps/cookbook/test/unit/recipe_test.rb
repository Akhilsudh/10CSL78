require File.dirname(__FILE__) + '/../test_helper'

class RecipeTest < ActiveSupport::TestCase
  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
